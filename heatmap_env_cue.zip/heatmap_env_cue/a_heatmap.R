# Load necessary libraries
library(readxl)
library(viridis)

# Select the Excel file manually
file_path <- file.choose()

# Read the Excel file
data <- read_excel(file_path)
head(data)

# Convert the data to a matrix
data_matrix <- as.matrix(data)

# Convert to numeric (if necessary)
data_matrix <- apply(data_matrix, 2, as.numeric)

# Reverse the order of rows to match the order in the Excel file
data_matrix <- data_matrix[nrow(data_matrix):1, ]

# Create a custom blue color palette
blue_palette <- colorRampPalette(c('#BFCFFF','#809FFF', '#00008B', '#001861'))

par(family = "Arial")

# Define the layout to include space for the legend
layout(matrix(c(1, 2), nrow = 1), widths = c(4, 1))

# Set margins for the heatmap
par(mar = c(5, 4, 4, 2) + 0.1)

# Create the heatmap
image(1:ncol(data_matrix), 1:nrow(data_matrix), t(data_matrix), col = blue_palette(256), axes = FALSE, xlab = "", ylab = "")
# Put the image in a box with customized settings
box(lty = "solid", col = "black", lwd = 0.5)


# Add y-axis labels on the left (reverse order)
axis(2, at = 1:nrow(data_matrix), labels = seq(1, 0, length.out = nrow(data_matrix)), las = 1, cex.axis = 0.7, tick = 0)

# Add x-axis labels at the top
axis(3, at = 1:ncol(data_matrix), labels = colnames(data_matrix), las = 1, cex.axis = 0.7, tick = 0, line = -0.5)

# Add axis labels
mtext("Rate of environmental change", side = 3, line = 2, cex = 1)
mtext("Cue availability", side = 2, line = 3, cex = 1)

# Set margins for the legend
par(mar = c(5, 1, 4, 2) + 0.1)

# Create the legend with the custom blue color palette
color_levels <- seq(min(data_matrix, na.rm = TRUE), max(data_matrix, na.rm = TRUE), length.out = 256)
legend_image <- matrix(color_levels, ncol = 1)
image(1, color_levels, t(legend_image), col = blue_palette(256), xaxt = "n", yaxt = "n", xlab = "", ylab = "")
axis(4, at = range(color_levels), labels = c(0, 1), las = 1, cex.axis = 0.7, tick = 0)
mtext("Mean compositionality", side = 3, line = 0.5, cex = 0.7)

# Reset layout
layout(1)

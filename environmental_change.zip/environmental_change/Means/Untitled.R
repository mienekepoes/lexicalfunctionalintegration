# List all CSV files in the directory
csv_files <- list.files(pattern = "\\.csv$")

# Read each CSV file
no_comp <- read.csv("meansframe_0comp.csv")
all_comp <- read.csv("meansframe_100.csv")
half_comp <- read.csv("meansframe_5050.csv")
almost_no_comp <- read.csv("meansframe_9010.csv")
little_bit_comp <- read.csv("meansframe_3070.csv")

# Define colors for each dataset
colors <- c("#001861", "#FF5733", "#008000", "#FFFF00", "#FF0000")

# Define the transparency level (alpha) for the blue color
alpha <- 0.5

# Create an empty plot
plot(1, type = "n", xlab = "Generation", ylab = "Mean compositionality", xlim = c(1, 1000), ylim = c(0, 100))

# Plot each dataset and add a legend
x <- 1:1000

lines(x, no_comp$mean_row, col = colors[1], lwd = 1.5)
polygon(c(x, rev(x)), c(no_comp$mean_row + no_comp$upper_bound, rev(no_comp$mean_row - no_comp$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

lines(x, all_comp$mean_row, col = colors[2], lwd = 1.5)
polygon(c(x, rev(x)), c(all_comp$mean_row + all_comp$upper_bound, rev(all_comp$mean_row - all_comp$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

lines(x, half_comp$mean_row, col = colors[3], lwd = 1.5)
polygon(c(x, rev(x)), c(half_comp$mean_row + half_comp$upper_bound, rev(half_comp$mean_row - half_comp$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

lines(x, almost_no_comp$mean_row, col = colors[4], lwd = 1.5)
polygon(c(x, rev(x)), c(almost_no_comp$mean_row + almost_no_comp$upper_bound, rev(almost_no_comp$mean_row - almost_no_comp$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

lines(x, little_bit_comp$mean_row, col = colors[5], lwd = 1.5)
polygon(c(x, rev(x)), c(little_bit_comp$mean_row + little_bit_comp$upper_bound, rev(little_bit_comp$mean_row - little_bit_comp$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

# Add legend
legend("topright", legend = c("no_comp", "all_comp", "half_comp", "almost_no_comp", "little_bit_comp"),
       col = colors, lwd = 2)
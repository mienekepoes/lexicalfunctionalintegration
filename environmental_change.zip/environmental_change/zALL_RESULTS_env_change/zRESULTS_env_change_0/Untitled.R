
# List all CSV files in the directory
csv_files <- list.files(pattern = "\\.csv$")

# Import all CSV files into a list of data frames
list_of_data_frames <- lapply(csv_files, read.csv)

# Access the first data frame in the list
first_data_frame <- list_of_data_frames[[1]]

# Print the first data frame to check
str(first_data_frame)

# Access the first data frame in the list and assign it to masterframe
masterframe <- list_of_data_frames[[1]]
str(masterframe)

# Iterate over all data frames in the list starting from the second one
for (i in 2:length(list_of_data_frames)) {
  # Extract the second variable from the current data frame
  variable <- list_of_data_frames[[i]][[2]]  # Assuming the second variable is always the second column
  
  # Add the extracted variable as a new column to masterframe
  masterframe <- cbind(masterframe, new_column = variable)
}
str(masterframe)

# Remove the "Generation" and "mean_compositionality" columns
masterframe <- masterframe[, !(names(masterframe) %in% c("Generation", "mean_compositionality"))]

# Print masterframe to check
print(masterframe)

# Calculate the row means of masterframe
means <- rowMeans(masterframe)

# Create a new data frame meansframe with the calculated means
meansframe <- data.frame(mean_row = means)

# Print meansframe to check
print(meansframe)

# Calculate SD and SE for each row of masterframe
masterframe$SD <- apply(masterframe, 1, sd)
masterframe$SE <- apply(masterframe, 1, function(x) sd(x) / sqrt(length(x)))

# Add SD and SE to meansframe
meansframe$SD <- masterframe$SD
meansframe$SE <- masterframe$SE

# Print meansframe to check
print(meansframe)

# Define the confidence level (e.g., 95%)
confidence_level <- 0.95

# Calculate the critical value (Z-score) based on the confidence level
z_score <- qnorm(1 - (1 - confidence_level) / 2)

# Calculate the margin of error
margin_of_error <- z_score * meansframe$SE

# Calculate the lower and upper bounds of the confidence interval
meansframe$lower_bound <- meansframe$mean_row - margin_of_error
meansframe$upper_bound <- meansframe$mean_row + margin_of_error

# Print meansframe with confidence intervals
print(meansframe)

# Define the x-axis (row numbers) and y-axis (mean values)
x <- 1:nrow(meansframe)
y <- meansframe$mean_row

# Create an empty plot with appropriate axes
plot(x, y, type = "n", xlab = "Generation", ylab = "Mean compositionality")

# Add points for the mean values
# Add a line connecting the mean values
lines(x, y, type = "l", col = rgb(0, 0, 1))

# Define the transparency level (alpha) for the blue color
alpha <- 0.5  # Adjust the value as needed

# Create the plot with the shaded confidence interval
polygon(c(x, rev(x)), c(meansframe$upper_bound, rev(meansframe$lower_bound)), col = rgb(0, 0, 1, alpha = alpha), border = NA)

# Save meansframe to a CSV file in the same directory
write.csv(meansframe, file = "meansframe_envch_0.csv", row.names = FALSE)


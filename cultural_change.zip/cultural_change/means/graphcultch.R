# List all CSV files in the directory
csv_files <- list.files(pattern = "\\.csv$")

# Import the last row of each CSV file into a list of data frames
list_of_data_frames <- lapply(csv_files, function(file) {
  df <- read.csv(file)
  return(df[nrow(df), , drop = FALSE])
})

# Combine all data frames into a single data frame
combined_df <- do.call(rbind, list_of_data_frames)

# Access the first data frame in the list and assign it to masterframe
masterframe <- combined_df
head(masterframe)

# Add a new column with values from 0 to 1 in increments of 0.05 as the first column
n <- nrow(masterframe)
increment_values <- seq(0, by = 0.1, length.out = n)
masterframe <- cbind(increment_values, masterframe)

# Rename the new column
colnames(masterframe)[1] <- "cue_avail"
head(masterframe)

# Delete the second row of masterframe
if (nrow(masterframe) >= 2) {
  masterframe <- masterframe[-2, ]
}
head(masterframe)

# Define the x and y values
x <- masterframe$cue_avail
y <- masterframe$mean_row

# Create the plot with appropriate axes
plot(x, y, type = "n", xlab = "Rate of cultural change", ylab = "Mean compositionality", cex.axis = 0.7)

# Add a line connecting the mean values
lines(x, y, type = "l", col = "#001861")

# Define the transparency level (alpha) for the blue color
alpha <- 0.5

# Create the polygon for the confidence interval
polygon(
  c(x, rev(x)), 
  c(masterframe$upper_bound, rev(masterframe$lower_bound)), 
  col = rgb(0, 0, 1, alpha = alpha), 
  border = NA
)

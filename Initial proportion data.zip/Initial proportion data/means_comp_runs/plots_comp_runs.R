
# List all CSV files in the directory
csv_files <- list.files(pattern = "\\.csv$")

# Read each CSV file
no_comp <- read.csv("meansframe_0comp.csv")
all_comp <- read.csv("meansframe_100.csv")
half_comp <- read.csv("meansframe_5050.csv")
almost_no_comp <- read.csv("meansframe_9010.csv")
little_bit_comp <- read.csv("meansframe_3070.csv")

# Define colors for each dataset
colors <- c("#488f31", "#58508d", "#bc5090", "#ff6361", "#ffa600")

# Define the transparency level (alpha) for the colors
alpha <- 0.5

# Create an empty plot with increased size
plot(1, type = "n", xlab = "Generation", ylab = "Mean compositionality", xlim = c(1, 1000), ylim = c(0, 100), cex.axis = 0.7)

# Plot each dataset and add a legend
x <- 1:1000

lines(x, no_comp$mean_row, col = colors[1], lwd = 1.5)
polygon(
  c(x, rev(x)), 
  c(no_comp$upper_bound, rev(no_comp$lower_bound)), 
  col = rgb(t(col2rgb(colors[1]))/255, alpha = alpha), 
  border = NA
)

lines(x, almost_no_comp$mean_row, col = colors[4], lwd = 1.5)
polygon(
  c(x, rev(x)), 
  c(almost_no_comp$upper_bound, rev(almost_no_comp$lower_bound)), 
  col = rgb(t(col2rgb(colors[4]))/255, alpha = alpha), 
  border = NA
)

lines(x, little_bit_comp$mean_row, col = colors[5], lwd = 1.5)
polygon(
  c(x, rev(x)), 
  c(little_bit_comp$upper_bound, rev(little_bit_comp$lower_bound)), 
  col = rgb(t(col2rgb(colors[5]))/255, alpha = alpha), 
  border = NA
)

lines(x, half_comp$mean_row, col = colors[3], lwd = 1.5)
polygon(
  c(x, rev(x)), 
  c(half_comp$upper_bound, rev(half_comp$lower_bound)), 
  col = rgb(t(col2rgb(colors[3]))/255, alpha = alpha), 
  border = NA
)

lines(x, all_comp$mean_row, col = colors[2], lwd = 1.5)
polygon(
  c(x, rev(x)), 
  c(all_comp$upper_bound, rev(all_comp$lower_bound)), 
  col = rgb(t(col2rgb(colors[2]))/255, alpha = alpha), 
  border = NA
)

# Add legend with title
legend("topleft", legend = c("0", "0.1", "0.3", "0.5", "1"),
       col = colors, lwd = 2, xpd = TRUE, bty = "n", horiz = TRUE, cex = 0.7, inset = c(0, -0.2),
       title = "Initial proportion of pattern fragmenters")
